# Info
def info():
    print('************************************************')
    print('This Package is Developed by JiaLe')
    print('Jia Le Version : v0.0.1')
    print('************************************************')
    return()

# Basic Math Section
    # Math: Add (+) 
def add_numbers(num1, num2):
    return num1 + num2

    # Math: Substract,Minus (-)
def substract_numbers(num1, num2):
    return num1 - num2

def minus_numbers(num1, num2):
    return num1 - num2

    # Math: Multiply (x,*)
def multiply_numbers(num1, num2):
    return num1 * num2

    # Math: Divide (÷,/)
def divide_numbers(num1, num2):
    return num1 / num2
