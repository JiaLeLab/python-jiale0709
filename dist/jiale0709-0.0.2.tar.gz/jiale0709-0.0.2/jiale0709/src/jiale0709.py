# Info, Version
def info():
    print("This is Jia Le's Python Library")
    print('This Library is Developed by Jia Le')
    
def version():
    print('Jia Le Version : v0.0.2') 
    print('Release Date : 11/27/2022')

# Math: Add, Plus (+) 
def plus_numbers(num1, num2):
    return num1 + num2    
    
def add_numbers(num1, num2):
    return num1 + num2

# Math: Substract, Minus (-)
def substract_numbers(num1, num2):
    return num1 - num2

def minus_numbers(num1, num2):
    return num1 - num2

# Math: Multiply (x, *)
def multiply_numbers(num1, num2):
    return num1 * num2

# Math: Divide (÷, /)
def divide_numbers(num1, num2):
    return num1 / num2
